from fastapi import APIRouter, HTTPException, status
# Import both functions you'll use
from interactors.module import generate_proposal_and_analyze, refine_proposal_llm
from utils.schema import ResponseModel, InputData, RefinementInput # Import new schema model
import logging

router = APIRouter()

@router.post("/generate_response", response_model=ResponseModel)
def generate_response(input_data: InputData):
    logging.info("Received input data for proposal generation and NLP analysis.")

    try:
        results = generate_proposal_and_analyze(
            paragraph=input_data.paragraph,
            query=input_data.query,
            topic=input_data.topic,
            audience=input_data.audience,
            analyze_input_sentiment=input_data.analyze_input_sentiment,
            analyze_output_sentiment=input_data.analyze_output_sentiment,
            extract_input_keywords=input_data.extract_input_keywords,
            extract_output_keywords=input_data.extract_output_keywords
        )

        if results.get("status") == "error":
            logging.error(f"Error from interactor: {results.get('message')}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=results.get('message', "An internal error occurred during processing.")
            )

        return ResponseModel(**results)

    except HTTPException as he:
        raise he
    except Exception as e:
        logging.error(f"Unhandled error in generating response: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {e}")


# --- NEW ENDPOINT FOR REFINEMENT ---
@router.post("/refine_proposal", response_model=ResponseModel)
def refine_proposal(refinement_input: RefinementInput):
    """
    Refines an existing proposal based on a specific instruction.
    """
    logging.info("Received refinement request for proposal.")
    try:
        refined_proposal_text = refine_proposal_llm(
            refinement_input.current_proposal_text,
            refinement_input.refinement_instruction
        )
        return ResponseModel(response=refined_proposal_text)
    except Exception as e:
        logging.error(f"Error during proposal refinement: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error during refinement: {e}")