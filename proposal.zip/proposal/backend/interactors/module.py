from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_google_genai import GoogleGenerativeAI
from langchain.prompts import PromptTemplate
from langchain.schema import StrOutputParser
from dotenv import load_dotenv
import os
import logging
from typing import List, Dict, Optional

query = "summarize the paragraph in one sentence"
load_dotenv()
google_api = os.getenv("GEMINI_API_KEY")

def edit_paragraph(paragraph:str):
    if not isinstance(paragraph, str):
        logging.warning("paragraph is not a string")
    logging.info("Editing paragraph")
    edited_paragraph = paragraph.strip()
    edited_paragraph = ' '.join(edited_paragraph.split())
    return edited_paragraph


def prompt_template_func(topic: str, audience: Optional[str] = None):
    audience_phrase = ""
    if audience:
        audience_phrase = f"specifically tailored for a {audience}."

    prompt_template = PromptTemplate.from_template(f"""
    Write a professional proposal for the topic: "{{topic}}" {audience_phrase} in a clear, concise, and persuasive manner.
    The proposal should include the following sections:

    1. **Introduction**: A brief introduction to the topic, explaining its importance and relevance.
    2. **Problem Statement**: Describe the problem or challenge that this topic addresses, highlighting the pain points for the client.
    3. **Proposed Solution**: Explain how the topic (or solution) resolves the problem. Make sure to mention key features and functionalities.
    4. **Key Benefits**: List the top benefits the client will gain by adopting this solution, including how it will improve their business.
    5. **Conclusion**: A strong closing paragraph, summarizing the main points and emphasizing why this is a valuable solution for the client.

    Ensure that the tone is professional, formal, and persuasive, and that the proposal is suitable for sending directly to a client.
    Keep it concise and to the point, focusing on the value proposition and client needs.
    """)
    generated_prompt = prompt_template.invoke({"topic": topic})
    return generated_prompt.text


paragraph = "I hope this message finds you well"
data = edit_paragraph(paragraph)

def get_query(query):
    logging.info("Cleaning up query")
    return query.strip()

embeddings = GoogleGenerativeAIEmbeddings(model="models/gemini-embedding-exp-03-07", google_api_key=google_api)
llm = GoogleGenerativeAI(model="gemini-2.0-flash", google_api_key=google_api)

proposal_pipeline = PromptTemplate.from_template("{paragraph}\n{query}\n{topic}\n\nGenerate a response based on the paragraph query and topic.") | llm | StrOutputParser()

def analyze_sentiment_llm(text: str) -> Optional[str]:
    if not text:
        return None
    logging.info(f"Analyzing sentiment for text length {len(text)}...")
    sentiment_prompt = PromptTemplate.from_template(
        "Analyze the sentiment of the following text. Respond only with 'positive', 'negative', or 'neutral'.\nText: {text}"
    )
    sentiment_chain = sentiment_prompt | llm | StrOutputParser()
    try:
        result = sentiment_chain.invoke({"text": text})
        result = result.strip().lower()
        if result in ["positive", "negative", "neutral"]:
            return result
        else:
            logging.warning(f"Unexpected sentiment analysis result: {result}")
            return "neutral"
    except Exception as e:
        logging.error(f"Error analyzing sentiment with LLM: {e}")
        return None

def extract_keywords_llm(text: str) -> Optional[List[str]]:
    if not text:
        return None
    logging.info(f"Extracting keywords for text length {len(text)}...")
    keywords_prompt = PromptTemplate.from_template(
        "Extract up to 5 main keywords from the following text, separated by commas. Do not include any other text.\nText: {text}"
    )
    keywords_chain = keywords_prompt | llm | StrOutputParser()
    try:
        result = keywords_chain.invoke({"text": text})
        keywords = [k.strip() for k in result.split(',') if k.strip()]
        return keywords
    except Exception as e:
        logging.error(f"Error extracting keywords with LLM: {e}")
        return None

# --- NEW FUNCTION FOR REFINEMENT ---
def refine_proposal_llm(current_proposal: str, instruction: str) -> str:
    """
    Refines an existing proposal based on a given instruction.
    """
    if not current_proposal or not instruction:
        logging.warning("No current proposal or instruction provided for refinement.")
        return current_proposal # Return original if no instruction

    logging.info(f"Refining proposal with instruction: {instruction}")
    refinement_prompt = PromptTemplate.from_template(
        "You are an expert proposal writer. Given the following existing proposal, please refine it based on the instruction provided.\n\n"
        "Existing Proposal:\n{current_proposal}\n\n"
        "Instruction:\n{instruction}\n\n"
        "Refined Proposal:"
    )
    refinement_chain = refinement_prompt | llm | StrOutputParser()
    try:
        refined_text = refinement_chain.invoke({
            "current_proposal": current_proposal,
            "instruction": instruction
        })
        return refined_text
    except Exception as e:
        logging.error(f"Error during proposal refinement: {e}")
        return f"Error refining proposal: {e}. Original proposal returned:\n{current_proposal}"


# --- MODIFIED generate_proposal_and_analyze function (no changes needed for this new feature) ---
def generate_proposal_and_analyze(
    paragraph: Optional[str],
    query: Optional[str],
    topic: Optional[str],
    audience: Optional[str] = None,
    analyze_input_sentiment: bool = False,
    analyze_output_sentiment: bool = False,
    extract_input_keywords: bool = False,
    extract_output_keywords: bool = False
) -> Dict:
    """
    Generates a proposal and performs NLP analysis based on flags,
    tailoring the proposal for a specific audience.
    """
    response_data = {
        "response": "",
        "status": "success",
        "message": "Operation completed successfully"
    }

    processed_paragraph = edit_paragraph(paragraph) if paragraph else ""
    processed_query = get_query(query) if query else ""
    processed_topic = topic if topic else ""
    processed_audience = audience if audience else ""

    if analyze_input_sentiment and (processed_paragraph or processed_query):
        text_to_analyze = f"{processed_paragraph} {processed_query}".strip()
        response_data["input_sentiment"] = analyze_sentiment_llm(text_to_analyze)

    if extract_input_keywords and (processed_paragraph or processed_query):
        text_to_analyze = f"{processed_paragraph} {processed_query}".strip()
        response_data["input_keywords"] = extract_keywords_llm(text_to_analyze)

    if not processed_topic:
        logging.warning("No topic provided for proposal generation.")
        response_data["status"] = "error"
        response_data["message"] = "No topic provided. Please provide a valid topic to generate a proposal."
        return response_data

    try:
        generated_full_prompt_text = prompt_template_func(processed_topic, processed_audience)
        logging.info(f"Generated Proposal Prompt: {generated_full_prompt_text}")

        proposal_text = proposal_pipeline.invoke({
            "paragraph": processed_paragraph,
            "query": processed_query,
            "topic": generated_full_prompt_text
        })
        response_data["response"] = proposal_text
        logging.info("Proposal generated successfully.")

        if analyze_output_sentiment and proposal_text:
            response_data["output_sentiment"] = analyze_sentiment_llm(proposal_text)

        if extract_output_keywords and proposal_text:
            response_data["output_keywords"] = extract_keywords_llm(proposal_text)

    except Exception as e:
        logging.error(f"Error in proposal generation or NLP analysis: {e}", exc_info=True)
        response_data["status"] = "error"
        response_data["message"] = f"Internal server error: {e}"

    return response_data


if __name__ == "__main__":
    sample_paragraph = "Our new software platform is designed to streamline operations and enhance security."
    sample_query = "Summarize the key features"
    sample_topic = "New Software Platform"
    sample_audience = "Technical Lead"

    print("\n--- Testing Initial Proposal Generation with Audience and NLP ---")
    results = generate_proposal_and_analyze(
        paragraph=sample_paragraph,
        query=sample_query,
        topic=sample_topic,
        audience=sample_audience,
        analyze_input_sentiment=True,
        extract_input_keywords=True,
        analyze_output_sentiment=True,
        extract_output_keywords=True
    )
    import json
    print(json.dumps(results, indent=2))

    print("\n--- Testing Proposal Refinement ---")
    if results["status"] == "success" and results["response"]:
        initial_proposal = results["response"]
        refinement_instruction = "Make the conclusion more assertive and add a call to action to schedule a demo."
        refined_proposal = refine_proposal_llm(initial_proposal, refinement_instruction)
        print("Refined Proposal:")
        print(refined_proposal)
    else:
        print("Initial proposal generation failed, cannot test refinement.")