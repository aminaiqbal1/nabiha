from pydantic import BaseModel
from typing import List, Optional, Dict

class InputData(BaseModel):
    paragraph: Optional[str] = None
    query: Optional[str] = None
    topic: Optional[str] = None
    audience: Optional[str] = None
    # New optional flags for NLP analysis
    analyze_input_sentiment: bool = False
    analyze_output_sentiment: bool = False
    extract_input_keywords: bool = False
    extract_output_keywords: bool = False

# --- NEW MODEL FOR REFINEMENT ---
class RefinementInput(BaseModel):
    current_proposal_text: str
    refinement_instruction: str
    # You might want to pass along other context if needed, e.g., original topic, audience etc.
    # For now, we assume the instruction is self-contained.

class ResponseModel(BaseModel):
    response: str
    status: str = "success"
    message: str = "Operation completed successfully"
    # Fields for NLP analysis results
    input_sentiment: Optional[str] = None
    output_sentiment: Optional[str] = None
    input_keywords: Optional[List[str]] = None
    output_keywords: Optional[List[str]] = None