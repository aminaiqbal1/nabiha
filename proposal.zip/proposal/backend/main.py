from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import routes.propsal as propsal
from log import setup_logging
import logging
setup_logging()


app = FastAPI()

# --- MODIFIED CORS CONFIGURATION ---
origins = [
    "http://localhost",        # For direct access to localhost
    "http://localhost:5173",   # Your Vite frontend's typical address
    "http://127.0.0.1:5173",   # Another common way Vite might resolve
    # If your Vite app runs on a different port, add it here too, e.g., "http://localhost:3000"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins, # <--- CHANGED THIS LINE
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
logging.info("CORS middleware added successfully")

# Include user routes
app.include_router(propsal.router)

"""This is the main entry point for the FastAPI application.
It initializes the app and includes the proposal"""

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)