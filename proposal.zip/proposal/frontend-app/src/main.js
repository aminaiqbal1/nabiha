// Store the current generated proposal globally so it can be refined
let currentGeneratedProposal = "";

document.getElementById('proposalForm').addEventListener('submit', async (event) => {
  event.preventDefault();

  const paragraph = document.getElementById('paragraph').value;
  const query = document.getElementById('query').value;
  const topic = document.getElementById('topic').value;
  const audience = document.getElementById('audience').value;

  const analyzeInputSentiment = document.getElementById('analyzeInputSentiment').checked;
  const extractInputKeywords = document.getElementById('extractInputKeywords').checked;
  const analyzeOutputSentiment = document.getElementById('analyzeOutputSentiment').checked;
  const extractOutputKeywords = document.getElementById('extractOutputKeywords').checked;

  const responseDisplay = document.getElementById('responseDisplay');
  const inputSentimentSpan = document.getElementById('inputSentiment');
  const inputKeywordsSpan = document.getElementById('inputKeywords');
  const outputSentimentSpan = document.getElementById('outputSentiment');
  const outputKeywordsSpan = document.getElementById('outputKeywords');
  const refinementSection = document.getElementById('refinementSection');


  // Reset displays and hide refinement section initially
  responseDisplay.innerHTML = 'Generating proposal and analyzing...';
  inputSentimentSpan.textContent = 'N/A';
  inputKeywordsSpan.textContent = 'N/A';
  outputSentimentSpan.textContent = 'N/A';
  outputKeywordsSpan.textContent = 'N/A';
  refinementSection.style.display = 'none'; // Hide refinement section until initial generation is done
  currentGeneratedProposal = ""; // Clear previous proposal on new generation


  try {
    const response = await fetch('http://127.0.0.1:8000/generate_response', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        paragraph,
        query,
        topic,
        audience,
        analyze_input_sentiment: analyzeInputSentiment,
        extract_input_keywords: extractInputKeywords,
        analyze_output_sentiment: analyzeOutputSentiment,
        extract_output_keywords: extractOutputKeywords,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.detail || `HTTP error! Status: ${response.status}`);
    }

    const data = await response.json();

    if (data.status === "error") {
        responseDisplay.innerHTML = `Error: ${data.message}`;
        console.error("Backend returned an error:", data.message);
        return;
    }

    currentGeneratedProposal = data.response; // Store the generated proposal
    responseDisplay.innerHTML = currentGeneratedProposal; // Display it

    // Display NLP analysis results
    inputSentimentSpan.textContent = data.input_sentiment || 'N/A';
    inputKeywordsSpan.textContent = data.input_keywords ? data.input_keywords.join(', ') : 'N/A';
    outputSentimentSpan.textContent = data.output_sentiment || 'N/A';
    outputKeywordsSpan.textContent = data.output_keywords ? data.output_keywords.join(', ') : 'N/A';

    refinementSection.style.display = 'block'; // Show refinement section after successful generation

  } catch (error) {
    console.error('Error:', error);
    responseDisplay.innerHTML = `Error: ${error.message}`;
    refinementSection.style.display = 'none'; // Keep hidden on error
  }
});


// --- NEW REFINEMENT LOGIC ---
document.getElementById('refinementForm').addEventListener('submit', async (event) => {
    event.preventDefault();

    const refinementInstruction = document.getElementById('refinementInstruction').value;
    const responseDisplay = document.getElementById('responseDisplay');
    const refineButton = document.getElementById('refineButton');

    if (!currentGeneratedProposal) {
        alert("Please generate an initial proposal first.");
        return;
    }
    if (!refinementInstruction.trim()) {
        alert("Please provide an instruction for refinement.");
        return;
    }

    // Indicate loading state
    const originalRefineButtonText = refineButton.textContent;
    refineButton.textContent = "Refining...";
    refineButton.disabled = true;

    const originalDisplayContent = responseDisplay.innerHTML; // Store current content
    responseDisplay.innerHTML = originalDisplayContent + '<br><br><i>Applying refinement...</i>'; // Append loading message


    try {
        const response = await fetch('http://127.0.0.1:8000/refine_proposal', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                current_proposal_text: currentGeneratedProposal,
                refinement_instruction: refinementInstruction,
            }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || `HTTP error! Status: ${response.status}`);
        }

        const data = await response.json();

        if (data.status === "error") {
            responseDisplay.innerHTML = originalDisplayContent + `<br><br>Error during refinement: ${data.message}`;
            console.error("Backend refinement returned an error:", data.message);
            return;
        }

        currentGeneratedProposal = data.response; // Update the stored proposal with the refined one
        responseDisplay.innerHTML = currentGeneratedProposal; // Display the refined proposal

        // Optionally, re-run output NLP analysis on the refined text
        // You would need to make another API call to /generate_response
        // or extend /refine_proposal to also return NLP analysis of the new text.
        // For simplicity, we are not re-analyzing output NLP in this snippet.

        document.getElementById('refinementInstruction').value = ''; // Clear instruction field

    } catch (error) {
        console.error('Error during refinement:', error);
        responseDisplay.innerHTML = originalDisplayContent + `<br><br>Error during refinement: ${error.message}`;
    } finally {
        refineButton.textContent = originalRefineButtonText;
        refineButton.disabled = false;
    }
});